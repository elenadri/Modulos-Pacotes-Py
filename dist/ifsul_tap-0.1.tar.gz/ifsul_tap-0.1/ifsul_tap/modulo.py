import math

num = int(input('Digite numero:'))
raiz = math.sqrt(num)
print('raiz de {} é igual a {}'.format(num,raiz))
