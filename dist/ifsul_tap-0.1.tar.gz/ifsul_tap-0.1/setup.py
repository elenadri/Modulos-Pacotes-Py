from setuptools import setup
setup(
    name="ifsul_tap",
    version="0.1",
    description="Este es un jemplo",
    author="Elena Adriana Moura Bueno",
    author_email="elenaadrianamourabueno@gmail.com",
    packages=['ifsul_tap']
)

